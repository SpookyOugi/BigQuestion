﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using System.IO;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Anketa test = new Anketa();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("BESEDILO", "NASLOV", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Želite shraniti anketo?", "Potrditev", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                test._timer = Timer.Content.ToString();
                test._vprasanje = Vprasanje.Text;
                test._odgovor = Odgovori.Text;

                XmlSerializer serializer = new XmlSerializer(typeof(Anketa));
                TextWriter writer = new StreamWriter(@"Podatki.xml");
                serializer.Serialize(writer, test);
                writer.Close();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Hočete zapreti okno?", "Potrditev", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Anketa));
            TextReader reader = new StreamReader(@"Podatki.xml");
            test = (Anketa)serializer.Deserialize(reader);
            reader.Close();

            Timer.Content = test._timer;
            Vprasanje.Text = test._vprasanje;
            Odgovori.Text = test._odgovor;
        }
    }
}
