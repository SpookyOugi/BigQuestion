﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WpfApplication1
{
    public class Anketa
    {
        public string _timer;
        public string _vprasanje;
        public string _odgovor;

        public Anketa()
        {
            _timer = "00:00";
            _vprasanje = "Ni aktualnih vprašanj";
            _odgovor = "Halo";
        }

        public string Timer
        {
            get { return _timer; }
            set { _timer = value; }
        }

        public string Vprasanje
        {
            get { return _vprasanje; }
            set { _vprasanje = value; }
        }

        public string Odgovor
        {
            get { return _odgovor; }
            set { _odgovor = value; }
        }

        public override string ToString()
        {
            return "Preostali čas: " + _timer + "\nVprašanje: " + _vprasanje + "\nIzbran odgovor: " + _odgovor;
        }
    }
}
